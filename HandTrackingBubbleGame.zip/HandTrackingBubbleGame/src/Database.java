import java.sql.*;
import java.security.MessageDigest;

public class Database {
    private String dbFile;

    public Database(String dbFile) {
        this.dbFile = dbFile;
    }

    public void init() {
        try (Connection conn = connect()) {
            Statement st = conn.createStatement();
            st.execute("PRAGMA foreign_keys = ON;");
            st.execute("CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT NOT NULL UNIQUE, password_hash TEXT NOT NULL, created_at DATETIME DEFAULT CURRENT_TIMESTAMP);");
            st.execute("CREATE TABLE IF NOT EXISTS scores (id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL, score INTEGER NOT NULL, played_at DATETIME DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE);");
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    private Connection connect() throws SQLException {
        String url = "jdbc:sqlite:" + dbFile;
        return DriverManager.getConnection(url);
    }

    // simple SHA-256 hash for passwords
    private String sha256(String input) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] out = md.digest(input.getBytes("UTF-8"));
            StringBuilder sb = new StringBuilder();
            for (byte b : out) sb.append(String.format("%02x", b));
            return sb.toString();
        } catch (Exception e) { throw new RuntimeException(e); }
    }

    public boolean registerUser(String username, String password) {
        String hash = sha256(password);
        String sql = "INSERT INTO users(username,password_hash) VALUES(?,?)";
        try (Connection c = connect(); PreparedStatement p = c.prepareStatement(sql)) {
            p.setString(1, username);
            p.setString(2, hash);
            p.executeUpdate();
            return true;
        } catch (SQLException ex) {
            // ex.printStackTrace();
            return false;
        }
    }

    public boolean checkLogin(String username, String password) {
        String sql = "SELECT password_hash FROM users WHERE username = ?";
        try (Connection c = connect(); PreparedStatement p = c.prepareStatement(sql)) {
            p.setString(1, username);
            ResultSet rs = p.executeQuery();
            if (rs.next()) {
                String stored = rs.getString(1);
                return stored.equals(sha256(password));
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return false;
    }

    public void saveScore(String username, int score) {
        String sql = "INSERT INTO scores(user_id,score) VALUES((SELECT id FROM users WHERE username=?),?)";
        try (Connection c = connect(); PreparedStatement p = c.prepareStatement(sql)) {
            p.setString(1, username);
            p.setInt(2, score);
            p.executeUpdate();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }
}
