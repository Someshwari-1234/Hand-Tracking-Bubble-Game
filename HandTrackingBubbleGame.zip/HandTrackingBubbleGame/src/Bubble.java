public class Bubble {
    public double x,y;
    public double radius;
    public double speed;
    public Bubble(double x,double y,double r,double s){ this.x=x; this.y=y; this.radius=r; this.speed=s; }
}
