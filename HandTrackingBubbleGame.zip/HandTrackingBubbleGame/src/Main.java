import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;

public class Main extends Application {
    private Database db;

    @Override
    public void start(Stage primaryStage) {
        db = new Database("handgame.db"); // SQLite file in working dir
        db.init(); // ensure tables exist

        primaryStage.setTitle("Hand Tracking Bubble Game - Login");

        // Login UI
        Label lblUser = new Label("Username:");
        TextField tfUser = new TextField();
        Label lblPass = new Label("Password:");
        PasswordField pf = new PasswordField();
        Button btnLogin = new Button("Login");
        Button btnRegister = new Button("Register");
        Label lblMsg = new Label();

        GridPane gp = new GridPane();
        gp.setVgap(8);
        gp.setHgap(8);
        gp.add(lblUser, 0, 0);
        gp.add(tfUser, 1, 0);
        gp.add(lblPass, 0, 1);
        gp.add(pf, 1, 1);
        gp.add(btnLogin, 0, 2);
        gp.add(btnRegister, 1, 2);
        gp.add(lblMsg, 0, 3, 2, 1);

        Scene loginScene = new Scene(gp, 350, 180);
        primaryStage.setScene(loginScene);
        primaryStage.show();

        btnRegister.setOnAction(e -> {
            String u = tfUser.getText().trim();
            String p = pf.getText().trim();
            if (u.isEmpty() || p.isEmpty()) { lblMsg.setText("Enter username and password"); return; }
            boolean ok = db.registerUser(u, p);
            lblMsg.setText(ok ? "Registered. You can login." : "Registration failed (user may exist).");
        });

        btnLogin.setOnAction(e -> {
            String u = tfUser.getText().trim();
            String p = pf.getText().trim();
            if (db.checkLogin(u, p)) {
                // open game window
                GameStage game = new GameStage(primaryStage, db, u);
                game.startGame();
            } else lblMsg.setText("Login failed. Check credentials.");
        });
    }

    public static void main(String[] args) {
        launch(args);
    }
}
