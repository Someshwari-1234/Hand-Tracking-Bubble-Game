import org.opencv.core.*;
import org.opencv.imgproc.Imgproc;
import org.opencv.videoio.VideoCapture;

import java.util.*;
import java.util.concurrent.atomic.AtomicReference;

/*
 * Simple hand tracker using OpenCV.
 * Must provide opencv Java bindings and native libs in java.library.path.
 */
public class HandTracker {
    private VideoCapture cap;
    private AtomicReference<Point> latestPoint = new AtomicReference<>(null);
    private volatile boolean running = true;
    private Thread th;

    static {
        // load native lib automatically if configured via -Djava.library.path
        try {
            System.loadLibrary(Core.NATIVE_LIBRARY_NAME);
        } catch (UnsatisfiedLinkError e) {
            System.err.println("Could not load OpenCV native library. Use -Djava.library.path to point to native libs.");
        }
    }

    public HandTracker() {
        cap = new VideoCapture(0);
        if (!cap.isOpened()) {
            System.err.println("Camera not opened");
            return;
        }
        th = new Thread(this::captureLoop);
        th.setDaemon(true);
        th.start();
    }

    private void captureLoop() {
        Mat frame = new Mat();
        Mat hsv = new Mat();
        Mat thresh = new Mat();
        Mat hierarchy = new Mat();
        while (running && cap.read(frame)) {
            // resize to width 800 for approximate mapping
            double scale = 800.0 / frame.width();
            Imgproc.resize(frame, frame, new Size(800, frame.height()*scale));
            // convert to HSV and threshold for a simple skin-like range
            Imgproc.cvtColor(frame, hsv, Imgproc.COLOR_BGR2HSV);
            // these ranges are approximate; tune as needed
            Core.inRange(hsv, new Scalar(0, 30, 60), new Scalar(20, 150, 255), thresh);
            // morphological cleanup
            Imgproc.erode(thresh, thresh, Imgproc.getStructuringElement(Imgproc.MORPH_ELLIPSE, new Size(5,5)));
            Imgproc.dilate(thresh, thresh, Imgproc.getStructuringElement(Imgproc.MORPH_ELLIPSE, new Size(7,7)));
            // find contours
            List<MatOfPoint> contours = new ArrayList<>();
            Imgproc.findContours(thresh, contours, hierarchy, Imgproc.RETR_EXTERNAL, Imgproc.CHAIN_APPROX_SIMPLE);
            double maxArea = 0; int idx = -1;
            for (int i=0;i<contours.size();i++) {
                double a = Imgproc.contourArea(contours.get(i));
                if (a > maxArea) { maxArea = a; idx = i; }
            }
            if (idx >= 0) {
                Moments m = Imgproc.moments(contours.get(idx));
                double cx = m.get_m10() / m.get_m00();
                double cy = m.get_m01() / m.get_m00();
                // map to JavaFX canvas coordinates (assumes canvas 800x600)
                double mappedX = cx;
                double mappedY = cy * (600.0 / frame.height());
                latestPoint.set(new Point(mappedX, mappedY));
            } else {
                latestPoint.set(null);
            }

            try { Thread.sleep(30); } catch (InterruptedException e) { break; }
        }
        cap.release();
    }

    public org.opencv.core.Point getHandPoint() {
        Point p = latestPoint.get();
        return p;
    }

    public void stop() {
        running = false;
        try { if (th != null) th.join(1000); } catch (InterruptedException e) { }
        if (cap != null && cap.isOpened()) cap.release();
    }
}
