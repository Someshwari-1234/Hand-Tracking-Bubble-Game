import javafx.animation.AnimationTimer;
import javafx.application.Platform;
import javafx.scene.Scene;
import javafx.scene.canvas.*;
import javafx.scene.control.Button;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;
import javafx.scene.paint.Color;

import org.opencv.core.Point;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Random;

public class GameStage {
    private Stage primary;
    private Database db;
    private String username;
    private HandTracker tracker;
    private ArrayList<Bubble> bubbles = new ArrayList<>();
    private int score = 0;
    private Random rnd = new Random();

    public GameStage(Stage primary, Database db, String username) {
        this.primary = primary;
        this.db = db;
        this.username = username;
    }

    public void startGame() {
        BorderPane root = new BorderPane();
        Canvas canvas = new Canvas(800, 600);
        GraphicsContext gc = canvas.getGraphicsContext2D();
        Button btnQuit = new Button("Quit & Save");
        root.setCenter(canvas);
        root.setBottom(btnQuit);
        Scene scene = new Scene(root);
        primary.setScene(scene);
        primary.setTitle("Hand Tracking Bubble Game - Playing as: " + username);
        primary.show();

        tracker = new HandTracker(); // starts capture internally
        // generate some bubbles
        for (int i=0;i<6;i++) bubbles.add(randomBubble());

        btnQuit.setOnAction(e -> {
            tracker.stop();
            db.saveScore(username, score);
            Platform.exit();
        });

        new AnimationTimer() {
            long lastSpawn = 0;
            @Override
            public void handle(long now) {
                // update bubbles
                Iterator<Bubble> it = bubbles.iterator();
                while (it.hasNext()) {
                    Bubble b = it.next();
                    b.y -= b.speed;
                    if (b.y + b.radius < 0) it.remove();
                }
                if (bubbles.size() < 6 && now - lastSpawn > 1_000_000_000L) {
                    bubbles.add(randomBubble()); lastSpawn = now;
                }

                // render
                gc.setFill(Color.LIGHTBLUE);
                gc.fillRect(0,0,canvas.getWidth(), canvas.getHeight());
                gc.setFill(Color.DARKBLUE);
                gc.fillText("Score: " + score, 10, 20);

                for (Bubble b : bubbles) {
                    gc.setFill(Color.rgb(135,206,250,0.8));
                    gc.fillOval(b.x-b.radius, b.y-b.radius, b.radius*2, b.radius*2);
                }

                // get hand point from tracker (screen coords relative to canvas) 
                Point hand = tracker.getHandPoint();
                if (hand != null) {
                    // draw a small circle
                    gc.setFill(Color.RED);
                    gc.fillOval(hand.x-10, hand.y-10, 20,20);
                    // check collisions
                    Iterator<Bubble> it2 = bubbles.iterator();
                    while (it2.hasNext()) {
                        Bubble b = it2.next();
                        double dx = b.x - hand.x;
                        double dy = b.y - hand.y;
                        double dist = Math.sqrt(dx*dx+dy*dy);
                        if (dist < b.radius + 20) {
                            score += 10;
                            it2.remove();
                        }
                    }
                }
            }
        }.start();
    }

    private Bubble randomBubble() {
        double x = 50 + rnd.nextDouble() * 700;
        double y = 600 + rnd.nextDouble()*200;
        double r = 20 + rnd.nextDouble()*40;
        double s = 0.5 + rnd.nextDouble()*2.0;
        return new Bubble(x,y,r,s);
    }
}
