# Hand Tracking Bubble Game (JavaFX + OpenCV + SQLite)

## Overview
A JavaFX desktop game that uses OpenCV for camera-based hand tracking. Players can register/login, play a bubble-popping game by moving their hand in front of the camera, and have their scores saved to a local SQLite database.

This package contains:
- `src/` — Java source files.
- `database.sql` — SQL schema to initialize the database.
- `assets/` — placeholder folder for images (empty).
- `README.md` — this file.

## Requirements
- Java 11+ (OpenJDK or Oracle JDK)
- JavaFX SDK compatible with your JDK (download from Gluon)
- OpenCV 4.x (Java bindings: opencv-<version>.jar and native library)
- sqlite-jdbc JAR (e.g., `sqlite-jdbc-3.36.0.3.jar`)

## Setup (quick)
1. **Unzip** the project and open a terminal in the project folder.
2. Create the SQLite DB from `database.sql` (or let the app create it automatically).
   ```
   sqlite3 handgame.db < database.sql
   ```
   (If sqlite3 is not available, the app will create the DB automatically on first run.)
3. Place the following jars somewhere accessible:
   - `opencv-<version>.jar` (from your OpenCV build)
   - native OpenCV libs (e.g., `libopencv_java454.so` on Linux, `opencv_java454.dll` on Windows, `libopencv_java454.dylib` on macOS)
   - `sqlite-jdbc-<version>.jar`
   - JavaFX libs

4. Run the app (example command — adjust paths):
   ```
   java --module-path /path/to/javafx/lib --add-modules javafx.controls,javafx.fxml      -cp "libs/opencv-4xx.jar:libs/sqlite-jdbc.jar:."      -Djava.library.path=/path/to/opencv/native      -jar HandTrackingBubbleGame.jar
   ```
   Alternatively, compile and run from your IDE (NetBeans/IntelliJ/Eclipse). Add JavaFX, OpenCV jar and native library, and sqlite-jdbc to classpath.

## Files (key)
- `src/Main.java` — JavaFX entry, login/register UI and game scene switching.
- `src/Database.java` — SQLite helper (JDBC).
- `src/HandTracker.java` — Bridge to OpenCV capturing and simple contour-based hand location.
- `src/Bubble.java` — Game bubble objects.
- `database.sql` — SQL to create tables and sample data.

## Notes & Tips
- The hand tracking algorithm here is intentionally simple: it uses background subtraction / thresholding to detect a primary contour (the hand). Lighting conditions and camera quality heavily affect results.
- For production-grade tracking, consider using MediaPipe (native) or more advanced models.
- Make sure the native OpenCV library version matches the opencv jar version.

If you want, I can:
- Produce a Maven `pom.xml` or Gradle `build.gradle`.
- Package a runnable jar with all dependencies (requires bundling native libs).
- Improve the tracking algorithm (e.g., skin color + convexity defects to detect finger tips).

Enjoy!